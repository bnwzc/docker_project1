db = db.getSiblingDB('project');

db.createCollection('statistics')