CREATE DATABASE IF NOT EXISTS project;
USE project;
CREATE TABLE IF NOT EXISTS height_weight (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(45) NOT NULL,
    height INT NOT NULL,
    weight INT NOT NULL,
    PRIMARY KEY (id)
);
